A continuación determinamos los requerimientos que el proyecto debe cumplir:
<br>
-Debe hacer uso de la librería de tareas.
<br>
-Debe poder insertar una tarea ( la tarea está compuesta por id, title, description y completed),
si el campo title se deja en blanco o nulo, debe registrarse con un texto "default", lo mismo sucede con 
el campo description.
<br>
-Se deben visualizar todas las tareas
<br>
-Se debe poder modificar una tarea para title, description y completed, Tomar en cuenta misma situación para los casos de inserción y 
si los campos están vacíos, si esos campos están vacíos, cada uno por aparte, mantendrán el dato anterior almacenado.
<br>
-Se debe poder eliminar una tarea, para ésto se solicitará el id de la tarea, si existe se mostrará el registro con id, title y description y 
se solicitará confirmación para eliminar, si la respuesta es "s" entonces se procede a eliminar.
<br>
-Completar una tarea, es un trabajo similar al punto de modificar una tarea, sin embargo solo modifica el estado completed a true.
<br>

![image](https://github.com/juangamboaabarca/Examen1/assets/146115119/42b8b8de-7b8a-43b6-b270-28ef2d38e4d0)
